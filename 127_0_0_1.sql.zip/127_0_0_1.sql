-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 31 déc. 2019 à 18:59
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `managerone`
--
DROP DATABASE IF EXISTS `managerone`;
CREATE DATABASE IF NOT EXISTS `managerone` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `managerone`;

-- --------------------------------------------------------

--
-- Structure de la table `task`
--

CREATE TABLE `task` (
  `id` bigint(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `creation_date` date DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `user_id` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `task`
--

INSERT INTO `task` (`id`, `title`, `description`, `creation_date`, `status`, `user_id`) VALUES
(6, 'task1', 'task11', '2019-12-17', 'Nok', 1),
(8, 'dkldkl', 'lldslds', '2019-12-15', 'Nok', 2),
(9, 'jkjjfddfd', 'fkdfkopr', '2019-12-10', 'NOK', 2),
(13, 'taskTest582125', 'TaskTEtyytyt', '2019-12-28', 'nokkoo', 2),
(14, 'taskT58899', 'Taskdddr', '2019-12-11', 'okkkdkdk', 2),
(17, 'taskT302114', 'Taskdddr', '2019-12-11', 'okkkdkdk', 5),
(20, 'taskT3dffdd', 'Tasvbdkdfk', '2019-12-11', 'okkkdkdk', 5),
(21, 'taskT3dffdd', 'Tasvbdkdfk', '2019-12-11', 'okkkdkdk', 5),
(22, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(23, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(24, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(25, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(26, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(27, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(28, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(29, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(31, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 13),
(33, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 12),
(34, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 12),
(35, 'uyui', 'jhjgfg', '2019-12-19', 'nokn', 12);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` bigint(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `create_date`) VALUES
(1, 'wallace', 'wa@gm.cm', '2019-12-30 23:29:25'),
(2, 'sala', 'sa@gr.cv', '2019-12-30 23:29:25'),
(3, 'steph', 'st@gh.cv', '2019-12-30 23:29:25'),
(5, 'sylv', 'syl@tty.com', '2019-12-30 23:29:25'),
(13, 'Wallace amiens', 'amiens@tcl.fr', '2019-12-30 23:29:25'),
(14, 'Wallace am', 'am@tcl.fr', '2019-12-30 23:29:25'),
(16, 'Ch7', 'ch7@tcl.fr', '2019-12-30 23:29:25'),
(33, 'dendiki23', 'mail22@jh.fr', '2019-12-30 23:45:15'),
(34, 'dendiki24', 'mail28@jh.fr', '2019-12-30 23:56:18'),
(36, 'lnk', 'lnk@gh.re', '2019-12-31 02:38:29'),
(37, 'retrereetrer', 'rtet@retr.gh', '2019-12-31 03:27:52'),
(38, 'diasbi', 'diqb@fhgfr', '2019-12-31 11:50:18'),
(40, 'baba', 'baba@tcl.fr', '2019-12-31 16:41:15'),
(41, 'baba2', 'baba2@tcl.fr', '2019-12-31 16:42:10'),
(42, 'balla', 'balla@tcl.fr', '2019-12-31 17:34:43');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_task_user_idx` (`user_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `task`
--
ALTER TABLE `task`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
